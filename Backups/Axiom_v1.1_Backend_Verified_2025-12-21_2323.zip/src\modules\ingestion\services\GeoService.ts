import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export class GeoService {
    async saveLocation(data: any) {
        // Map input to Database Schema
        return await prisma.propertyManifest.create({
            data: {
                placeId: data.placeId,
                address: data.address,
                latitude: data.latitude,
                longitude: data.longitude,
                sourceType: data.sourceType,
                rawSourceData: data.rawSourceData || {},
                status: 'PENDING'
            }
        });
    }
}