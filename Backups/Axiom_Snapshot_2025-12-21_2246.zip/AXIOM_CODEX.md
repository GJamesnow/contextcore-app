﻿# AXIOM PROJECT CODEX
# Snapshot Date: 2025-12-21_2246
# Role: Senior Systems Architect (20x Mode)

## 1. OPERATIONAL DOCTRINE (The "20x" Rules)
- **First Principles Engineering:** Do not use wrappers or shortcuts. Use the native runtime (Node.js) to generate files programmatically.
- **Parsing Immunity:** Never paste complex JSON/Text directly into PowerShell. Use JavaScript generators to avoid Encoding/BOM errors.
- **Verification Loops:** Always verify a command succeeded (e.g., check Port 3000 is actually dead) before proceeding.
- **Titanium Genesis:** The environment is volatile. Rebuilding from scratch (Scorched Earth) is preferred over patching.

## 2. ARCHITECTURE STATUS
- **Backend:** Node.js + Express + TypeScript
- **Database:** PostgreSQL (Docker: axiom_db_core)
- **ORM:** Prisma (Schema verified and synced)
- **Ingestion:** Validated via 'GeoService' injection.

## 3. KNOWN HAZARDS
- **PowerShell Encoding:** Windows adds invisible BOM characters to text files. ALWAYS use Node.js 'fs' module to write config files.
- **Docker Latency:** Database container reports "Running" before it is ready. Scripts must wait for 'pg_isready'.
- **Zombie Processes:** Port 3000 often hangs. Aggressive PID killing is required.

## 4. CURRENT STATE
- API is LIVE at http://localhost:3000
- Ingestion Endpoint '/api/ingest/geo' is verified.
- Database connection is healthy.
